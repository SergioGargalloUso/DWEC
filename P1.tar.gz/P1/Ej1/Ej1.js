function aviso(){
    
    alert("Esta imagen no esta disponible");
}
function holamundo(){
    console.log("Hola mundo");
}