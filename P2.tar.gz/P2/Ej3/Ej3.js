// Crear una matriz de 3x3 rellena de números enteros
let matriz = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
];

// Mostrar los elementos de la diagonal principal
console.log("Elementos de la diagonal principal:");
for (let x = 0; x < matriz.length; x++) {
    console.log(matriz[x][x]); 
}

