// Creamos un Array con nombres
let gruposMusica = ["One OK Rock", "Imagine Dragons", "Black Pink", "Eladio Carrion", "Aerosmith"];

// Recorremos el array y añadimos dos para sacar impares ya que empieza en 1
for (let x = 1; x < gruposMusica.length; x+2) {
    console.log(gruposMusica[x]);
}
